package com.youtirsin.blah;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BlahApplication {

	public static void main(String[] args) {
		SpringApplication.run(BlahApplication.class, args);
	}

}
